-- =====================================================================
-- SmartLibrary Application — PostgreSQL Database Schema
-- Limkokwing University of Creative Technology
-- =====================================================================

-- Clean slate (safe to re-run during development)
DROP TABLE IF EXISTS book_club_members CASCADE;
DROP TABLE IF EXISTS book_clubs CASCADE;
DROP TABLE IF EXISTS loans CASCADE;
DROP TABLE IF EXISTS books CASCADE;
DROP TABLE IF EXISTS authors CASCADE;
DROP TABLE IF EXISTS members CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS roles CASCADE;

-- =====================================================================
-- 1. ROLES  (Librarian, Member)
-- =====================================================================
CREATE TABLE roles (
    role_id     SERIAL PRIMARY KEY,
    role_name   VARCHAR(30) NOT NULL UNIQUE CHECK (role_name IN ('Librarian', 'Member'))
);

INSERT INTO roles (role_name) VALUES ('Librarian'), ('Member');

-- =====================================================================
-- 2. USERS  (base table — maps to the Python User base class)
-- =====================================================================
CREATE TABLE users (
    user_id         SERIAL PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    email           VARCHAR(120) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(120) NOT NULL,
    role_id         INTEGER NOT NULL REFERENCES roles(role_id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 3. MEMBERS  (1:1 extension of users — maps to the Member subclass)
-- =====================================================================
CREATE TABLE members (
    member_id           SERIAL PRIMARY KEY,
    user_id             INTEGER NOT NULL UNIQUE REFERENCES users(user_id) ON DELETE CASCADE,
    membership_date     DATE NOT NULL DEFAULT CURRENT_DATE
);

-- =====================================================================
-- 4. AUTHORS
-- =====================================================================
CREATE TABLE authors (
    author_id   SERIAL PRIMARY KEY,
    first_name  VARCHAR(80) NOT NULL,
    last_name   VARCHAR(80) NOT NULL,
    bio         TEXT
);

-- =====================================================================
-- 5. BOOKS
-- =====================================================================
CREATE TABLE books (
    book_id             SERIAL PRIMARY KEY,
    title               VARCHAR(250) NOT NULL,
    isbn                VARCHAR(20) NOT NULL UNIQUE,
    genre               VARCHAR(60),
    author_id           INTEGER NOT NULL REFERENCES authors(author_id),
    total_copies        INTEGER NOT NULL CHECK (total_copies >= 0) DEFAULT 1,
    available_copies    INTEGER NOT NULL CHECK (available_copies >= 0) DEFAULT 1,
    published_date      DATE,
    CHECK (available_copies <= total_copies)
);

-- =====================================================================
-- 6. LOANS   (business rules: max 3 active loans/member, due = +7 days)
-- =====================================================================
CREATE TABLE loans (
    loan_id       SERIAL PRIMARY KEY,
    member_id     INTEGER NOT NULL REFERENCES members(member_id),
    book_id       INTEGER NOT NULL REFERENCES books(book_id),
    borrow_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    due_date      DATE NOT NULL,
    return_date   DATE,
    status        VARCHAR(15) NOT NULL DEFAULT 'ACTIVE'
                  CHECK (status IN ('ACTIVE', 'RETURNED', 'OVERDUE')),
    CHECK (return_date IS NULL OR return_date >= borrow_date)
);

-- =====================================================================
-- 7. BOOK CLUBS
-- =====================================================================
CREATE TABLE book_clubs (
    club_id         SERIAL PRIMARY KEY,
    name            VARCHAR(120) NOT NULL,
    description     TEXT,
    current_book_id INTEGER REFERENCES books(book_id),
    created_by      INTEGER NOT NULL REFERENCES users(user_id)
);

-- =====================================================================
-- 8. BOOK CLUB MEMBERS  (many-to-many junction table)
-- =====================================================================
CREATE TABLE book_club_members (
    club_id      INTEGER NOT NULL REFERENCES book_clubs(club_id) ON DELETE CASCADE,
    member_id    INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
    joined_date  DATE NOT NULL DEFAULT CURRENT_DATE,
    PRIMARY KEY (club_id, member_id)
);

-- =====================================================================
-- BUSINESS RULE 1: Auto-set due_date = borrow_date + 7 days
-- =====================================================================
CREATE OR REPLACE FUNCTION set_due_date()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.due_date IS NULL THEN
        NEW.due_date := NEW.borrow_date + INTERVAL '7 days';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_due_date
BEFORE INSERT ON loans
FOR EACH ROW
EXECUTE FUNCTION set_due_date();

-- =====================================================================
-- BUSINESS RULE 2: Max 3 active loans per member
-- =====================================================================
CREATE OR REPLACE FUNCTION enforce_loan_limit()
RETURNS TRIGGER AS $$
DECLARE
    active_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO active_count
    FROM loans
    WHERE member_id = NEW.member_id
      AND status = 'ACTIVE';

    IF active_count >= 3 THEN
        RAISE EXCEPTION 'Member % already has 3 active loans (limit reached)', NEW.member_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_enforce_loan_limit
BEFORE INSERT ON loans
FOR EACH ROW
EXECUTE FUNCTION enforce_loan_limit();

-- =====================================================================
-- BUSINESS RULE 3: Adjust book availability on borrow / return
-- =====================================================================
CREATE OR REPLACE FUNCTION adjust_book_availability()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE books SET available_copies = available_copies - 1
        WHERE book_id = NEW.book_id AND available_copies > 0;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'Book % has no available copies', NEW.book_id;
        END IF;

    ELSIF TG_OP = 'UPDATE' AND OLD.status = 'ACTIVE' AND NEW.status = 'RETURNED' THEN
        UPDATE books SET available_copies = available_copies + 1
        WHERE book_id = NEW.book_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_adjust_availability_insert
BEFORE INSERT ON loans
FOR EACH ROW
EXECUTE FUNCTION adjust_book_availability();

CREATE TRIGGER trg_adjust_availability_update
BEFORE UPDATE ON loans
FOR EACH ROW
EXECUTE FUNCTION adjust_book_availability();

-- =====================================================================
-- INDEXES  (support the required search/filter/sort and loan lookups)
-- =====================================================================
CREATE INDEX idx_books_title        ON books (title);
CREATE INDEX idx_books_genre        ON books (genre);
CREATE INDEX idx_books_author_id    ON books (author_id);
CREATE UNIQUE INDEX idx_books_isbn  ON books (isbn);

CREATE INDEX idx_loans_member_id    ON loans (member_id);
CREATE INDEX idx_loans_book_id      ON loans (book_id);
CREATE INDEX idx_loans_status       ON loans (status);
CREATE INDEX idx_loans_due_date     ON loans (due_date);

CREATE INDEX idx_users_role_id      ON users (role_id);
CREATE UNIQUE INDEX idx_users_email ON users (email);

CREATE INDEX idx_bcm_member_id      ON book_club_members (member_id);

-- =====================================================================
-- SEED DATA (minimal, for development/testing)
-- =====================================================================
INSERT INTO users (username, email, password_hash, full_name, role_id)
VALUES ('admin.librarian', 'librarian@limkokwing.edu.sl', 'CHANGE_ME_HASH', 'Aminata Kargbo',
        (SELECT role_id FROM roles WHERE role_name = 'Librarian'));

INSERT INTO users (username, email, password_hash, full_name, role_id)
VALUES ('j.sesay', 'j.sesay@student.limkokwing.edu.sl', 'CHANGE_ME_HASH', 'Joseph Sesay',
        (SELECT role_id FROM roles WHERE role_name = 'Member'));

INSERT INTO members (user_id) VALUES ((SELECT user_id FROM users WHERE username = 'j.sesay'));

INSERT INTO authors (first_name, last_name) VALUES ('Chinua', 'Achebe');
INSERT INTO books (title, isbn, genre, author_id, total_copies, available_copies)
VALUES ('Things Fall Apart', '978-0385474542', 'Fiction',
        (SELECT author_id FROM authors WHERE last_name = 'Achebe'), 3, 3);
